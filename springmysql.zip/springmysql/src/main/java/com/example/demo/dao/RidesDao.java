package com.example.demo.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.modal.Rides;

public interface RidesDao extends CrudRepository<Rides, Integer> {

}
